"""
Motion features (angles, displacement, velocity, acceleration, direction).

Owner:
    Module 03 — Optimization Sequence (Teammate 4: temporal section)

Note:
    The top-level directory name starts with a digit, so it cannot be imported
    with a normal `import` statement. The integration-time loading strategy is
    documented in the root README.md. Do not add imports such as
    `from 02_yolo import ...`.
"""
